# Our Home App — Setup Guide
## Matt & Tara's Home Project Planner

---

## What you'll need
- A free Google account (for Firebase)
- A free Vercel account (for hosting)
- Node.js installed on your computer (nodejs.org — click the LTS download)

Total time: ~15 minutes

---

## STEP 1 — Set up Firebase (your live database)

1. Go to **console.firebase.google.com** and sign in with your Google account
2. Click **"Add project"** → name it `our-home` → click through the setup (disable Google Analytics if asked, it's optional)
3. Once inside your project, click **"Firestore Database"** in the left sidebar
4. Click **"Create database"** → choose **"Start in test mode"** → pick a region close to you → click **Done**
5. Now click the **gear icon** (⚙️) next to "Project Overview" → **Project settings**
6. Scroll down to **"Your apps"** → click the **`</>`** (web) icon
7. Register app with nickname `our-home` → click **"Register app"**
8. You'll see a block of code with your config. Copy these 6 values:
   - apiKey
   - authDomain
   - projectId
   - storageBucket
   - messagingSenderId
   - appId

---

## STEP 2 — Add your Firebase config to the app

1. Open the file: `src/firebase.js`
2. Replace each `PASTE_YOUR_..._HERE` placeholder with your values from Step 1
3. Save the file

Example of what it should look like when done:
```js
const firebaseConfig = {
  apiKey: "AIzaSyAbc123...",
  authDomain: "our-home-abc12.firebaseapp.com",
  projectId: "our-home-abc12",
  storageBucket: "our-home-abc12.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123..."
}
```

---

## STEP 3 — Install and test locally

Open Terminal (Mac) or Command Prompt (Windows) and run:

```bash
cd ourhome
npm install
npm run dev
```

Open your browser to **http://localhost:5173** — you should see the app working!

---

## STEP 4 — Deploy to Vercel (get your shareable link)

1. Go to **vercel.com** and sign up with your GitHub account
   - If you don't have GitHub: github.com → sign up (free)

2. Push the project to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Our Home app"
   ```
   Then create a new repo at github.com/new and follow their instructions to push.

3. In Vercel: click **"Add New Project"** → import your GitHub repo → click **Deploy**

4. In ~60 seconds you'll get a live URL like: `https://our-home-xyz.vercel.app`

**That's your link!** Share it with Tara. Open it on both iPhones in Safari and add to home screen.

---

## STEP 5 — Add to iPhone home screens

On each iPhone:
1. Open Safari → go to your Vercel URL
2. Tap the **Share button** (box with arrow ↑)
3. Tap **"Add to Home Screen"**
4. Name it **"Our Home"** → tap Add

It will appear as an app icon and open fullscreen.

---

## How real-time sync works

- Every message, status change, budget update, and mood board item is saved instantly to Firebase
- Both phones see changes within 1–2 seconds automatically
- No refresh needed — it's fully live

---

## Firestore monitoring (watch live updates)

To watch updates happen in real time from Firebase console:

1. Go to console.firebase.google.com → your project
2. Click **Firestore Database** in the sidebar
3. You'll see your `projects` collection and `messages` subcollections live
4. As Matt or Tara make changes in the app, you'll see the data update in real time here

---

## Troubleshooting

**App shows "Connecting…" forever**
→ Check your firebase.js config values are correct (no extra spaces or quotes)

**"Permission denied" error**
→ In Firebase Console → Firestore → Rules, make sure it says:
```
allow read, write: if true;
```
(This is the test mode default — fine for personal use)

**Vercel build fails**
→ Make sure you've filled in all 6 values in firebase.js before pushing to GitHub
